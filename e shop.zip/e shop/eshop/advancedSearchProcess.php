<?php

require "connection.php";

$k = $_POST["k"];
$c = $_POST["c"];
$b = $_POST["b"];
$m = $_POST["m"];
$con = $_POST["con"];
$clr = $_POST["clr"];
$pf = $_POST["pf"];
$pt = $_POST["pt"];

$cats;
$brs;
$mos;
$cons;
$cols;

if ($c == 0) {
    $cats = "";
} else {
    $cats = "AND `category` = '" . $c . "'";
}

if ($b == 0) {
    $brs = "";
} else {
    $brs = "AND `brand_id` = '" . $b . "'";
}

if ($m == 0) {
    $mos = "";
} else {
    $mos = "AND `model_id` = '" . $m . "'";
}

if ($con == 0) {
    $cons = "";
} else {
    $cons = "AND `condition_id` = '" . $con . "'";
}

if ($clr == 0) {
    $cols = "";
} else {
    $cols = "AND `color_id` = '" . $clr . "'";
}

$pftc = "";
if (empty($pf) && !empty($pt)) {

    $pftc = "AND `price` <= '" . $pt . "'";
} else if (!empty($pf) && empty($pt)) {

    $pftc = "AND `price` >= '" . $pf . "'";
} else if (!empty($pf) && !empty($pt)) {

    $pftc = "AND `price` >= '" . $pf . "' AND `price` <= '" . $pt . "'";
}

$products = Database::search("SELECT * FROM `product`  INNER JOIN `model_has_brand` ON `product`.model_has_brand_id = `model_has_brand`.id 
WHERE `description` LIKE '%" . $k . "%' $cats $brs $mos $cons $cols $pftc");
$pdr = $products->num_rows;

?>

<div class="row">

    <?php

    if ($pdr == 0) {
    ?>
        <h2 class="text-center fw-bold text-danger">Results Not Found!</h2>
        <?php
    } else {

        for ($i = 0; $i < $pdr; $i++) {
            $srow = $products->fetch_assoc();

        ?>

            <div class="mb-3 col-12 col-lg-6 mt-3">
                <div class="row g-0">
                    <div class="card">
                        <div class="row g-0">
                            <div class="col-md-4 mt-2 mb-2">

                                <?php

                                $imgrs = Database::search("SELECT * FROM `images` WHERE `product_id` = '" . $srow["id"] . "' ");
                                $imgn = $imgrs->num_rows;
                                $imgd = $imgrs->fetch_assoc();

                                if ($imgn == 0) {
                                ?>
                                    <img src="resources/no-image.jpg" class="img-fluid rounded-start">
                                <?php
                                } else {

                                    echo $imgd["code"];
                                }
                                ?>

                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title fw-bold"><?php echo $srow["title"]; ?>
                                    </h5>
                                    <span class="card-text fw-bold text-primary">Rs.
                                        <?php echo $srow["price"]; ?> .00</span>
                                    <br>
                                    <span class="card-text fw-bold text-success"><?php echo $srow["qty"]; ?>
                                        items left
                                    </span>
                                    <div class="row mt-1 gy-2 gx-6 ">
                                        <div class="col-12 col-lg-6 d-grid">
                                            <a class="btn btn-success" style="font-size: 14px;" href="#">Buy&nbsp;Now</a>
                                        </div>

                                        <div class="col-12 col-lg-6 d-grid">
                                            <a class="btn btn-primary" style="font-size: 14px;" href="#">Add&nbsp;to&nbsp;Cart</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <?php
        }
    }


    ?>

</div>