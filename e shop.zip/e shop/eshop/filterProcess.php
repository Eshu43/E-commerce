<?php

session_start();
$user = $_SESSION["u"];

require "connection.php";

// $aray;

$search = $_POST["s"];
$age = $_POST["a"];
$qty = $_POST["q"];
$condition = $_POST["c"];

$search;
$age;
$qty;
$condition;

if ($age == 0) {
    $age = "";
} elseif ($age == 1) {
    $age = "ORDER BY `datetime_added` ASC ";
} else {
    $age = "ORDER BY `datetime_added` DESC ";
}

if ($qty == 0) {
    $qty = "";
} elseif ($qty == 1) {
    $qty = "ORDER BY `qty` ASC ";
} else {
    $qty = "ORDER BY `qty` DESC ";
}

if ($condition == 0) {
    $condition = "";
} elseif ($condition == 1) {
    $condition = "AND `condition_id` = '1' ";
} else {
    $condition = "AND `condition_id` = '2' ";
}


$products = Database::search("SELECT * FROM `product` WHERE `title` LIKE '%" . $search . "%' $age $qty $condition");
$pdr = $products->num_rows;


if ($pdr == 0) {
?>
    <h2 class="text-center fw-bold text-danger mt-5">Results Not Found!</h2>
    <?php
} else {
    for ($i = 0; $i < $pdr; $i++) {
    ?>

        <div class=" mb-3 col-12 col-lg-6">
            <div class="row g-0">
                <div class="card mb-3 col-12 col-lg-10 mt-3 ms-lg-5" style="max-width: 540px;">
                    <div class="row g-0">
                        <?php

                        $srow = $products->fetch_assoc();


                        $pimgrs = Database::search("SELECT * FROM `images` WHERE `product_id` = '" . $srow["id"] . "' ");
                        $pimgn = $pimgrs->num_rows;
                        $pir = $pimgrs->fetch_assoc();

                        if ($pimgn == 0) {
                        ?>
                            <div class="col-md-4 mt-4">
                                <img src="resources/no-image.jpg" class="img-fluid d-grid">
                            </div>
                        <?php
                        } else {
                        ?>
                            <div class="col-md-4 mt-4">
                                <img src="<?php echo $pir["code"]; ?>" class="img-fluid d-grid">
                            </div>
                        <?php
                        }

                        ?>


                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?php echo $srow["title"]; ?></h5>
                                <span class="text-primary fw-bold">Rs.<?php echo $srow["price"]; ?></span><br>
                                <span class="text-success fw-bold"><?php echo $srow["qty"]; ?> Items Left</span><br>
                                <div class="form-check form-switch">
                                    <input class="form-check-input shadow-none" type="checkbox" role="switch" id="check" onchange="changeStatus(<?php echo $srow['id']; ?>);"
                                     <?php 
                                    if ($srow["status_id"] == 2) { ?> 
                                    checked 
                                    <?php 
                                } ?> />
                                    <label class="form-check-label text-info fw-bold" for="check" id="checklabel<?php echo $srow['id']; ?>">
                                        <?php
                                        if ($srow["status_id"] == 2) {

                                            echo "Make Your Product Active";
                                        } else {
                                            echo "Make Your Product Deactive";
                                        }
                                        ?></label>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-md-6 d-grid g-1">
                                                <a href="#" class="btn btn-success shadow-none" onclick="sendid(<?php echo $srow['id']; ?>);">Update</a>
                                            </div>
                                            <div class="col-md-6 d-grid g-1">
                                                <a href="#" class="btn btn-danger shadow-none" onclick="deleteModel(<?php echo $srow['id']; ?>);">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="deleteModel<?php echo $srow['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bolder text-warning" id="exampleModalLabel">Warning...</h5>
                        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are You Sure You Want To Delete This Product?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success shadow-none" data-bs-dismiss="modal">No</button>
                        <button type="button" class="btn btn-danger shadow-none" onclick="deleteProduct(<?php echo $srow['id']; ?>);">Yes</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
<?php
    }
}
?>